

# Full Spectrum Sun Calculator

A minimal, Dieter Rams-inspired calculator for tracking sun exposure benefits. Monochrome design with bold, saturated color reserved only for skin tones and sunlight visualization.

## Pages & Layout

### Single-Page Calculator
- **Clean, grid-based layout** with tight kerning and line height on headings
- Typography-forward design using a monospace or geometric sans-serif feel
- Generous whitespace, minimal UI chrome

## Input Section (Top)

1. **Zip Code Input** — fetches current weather, UV Index, and sun times via a free weather API (Open-Meteo, no key required)
2. **Skin Color Selector** — 6 Fitzpatrick types shown as bold, saturated skin-tone swatches (the one pop of color in the UI). Selecting one sets the skin factor.
3. **Body Exposure Toggle** — Three options: Face/Hands (10%), Shorts & T-shirt (40%), Swimsuit (80%) — shown as minimal silhouette icons
4. **Time of Day Selector** — Four periods: Sunrise, Morning/Midday (10am–2pm), Afternoon, Sunset — with a slider or segmented control
5. **Duration Slider** — Adjust minutes outdoors (0–120 min)

## Output Section (Below Inputs)

### Vitamin D Solar Budget
- Large, prominent IU number calculated from the formula: `20,000 × Hours × UVI_factor × Skin_factor × Body_factor`
- Progress bar toward daily recommended 600–4000 IU
- Small note showing the math breakdown

### Red Light Therapy Equivalent
- Shows how many minutes of red light panel therapy the sunrise/sunset exposure equals
- Based on the 10 mW/cm² (sun) vs 30–50 mW/cm² (panel) ratio
- Only shows meaningful values during sunrise/sunset time selection

### Solar Spectrum Benefits Panel
- A compact reference table showing all 7 light types (UVB, UVA, Blue, Red, NIR, FIR) with:
  - Benefit name
  - Target area
  - Best time of day
  - Active/inactive indicator based on selected time of day
- Sunlight wavelength visualization strip at the top — bold saturated colors from violet through red to infrared (the second intentional use of color)

## Data & API
- **Open-Meteo API** (free, no key) for UV Index and weather by coordinates
- **Zip-to-coordinates** conversion using a lightweight geocoding approach
- All calculations done client-side

## Design System
- **Monochrome palette**: black, white, and grays only for all UI elements
- **Color exceptions**: Fitzpatrick skin swatches and the solar spectrum visualization strip use bold, saturated color
- **Typography**: Tight letter-spacing (-0.02–0.05em) and tight line-height (1.0–1.1) on headings
- **Minimal borders**, subtle separators, data-ink ratio maximized (Tufte principle)

