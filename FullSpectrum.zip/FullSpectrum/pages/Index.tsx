import { useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { SkinTypeSelector } from '@/components/SkinTypeSelector';
import { BodyExposureSelector } from '@/components/BodyExposureSelector';
import { TimePeriodSelector } from '@/components/TimePeriodSelector';
import { SpectrumStrip } from '@/components/SpectrumStrip';
import { SpectrumTable } from '@/components/SpectrumTable';
import {
  SKIN_TYPES,
  BODY_EXPOSURE,
  TIME_PERIODS,
  calculateVitaminD,
  calculateRedLightEquivalent,
} from '@/lib/solar-calculations';
import { geocodeZip, getWeather } from '@/lib/weather-api';

const Index = () => {
  const [zip, setZip] = useState('');
  const [uvi, setUvi] = useState<number | null>(null);
  const [location, setLocation] = useState('');
  const [temperature, setTemperature] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [skinIndex, setSkinIndex] = useState(0);
  const [bodyIndex, setBodyIndex] = useState(1);
  const [timeIndex, setTimeIndex] = useState(1);
  const [duration, setDuration] = useState(30);

  const fetchWeather = useCallback(async () => {
    if (zip.length < 3) return;
    setLoading(true);
    const geo = await geocodeZip(zip);
    if (geo) {
      const weather = await getWeather(geo.latitude, geo.longitude);
      if (weather) {
        setUvi(weather.uvi);
        setTemperature(weather.temperature);
        setLocation(`${geo.name}${geo.admin1 ? `, ${geo.admin1}` : ''}`);
      }
    }
    setLoading(false);
  }, [zip]);

  const handleZipKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') fetchWeather();
  };

  const hours = duration / 60;
  const skin = SKIN_TYPES[skinIndex];
  const body = BODY_EXPOSURE[bodyIndex];
  const time = TIME_PERIODS[timeIndex];

  const currentUvi = uvi ?? 5;
  const vitaminD = calculateVitaminD(hours, currentUvi, skin.factor, body.factor, time.uviFactor);
  const dailyTarget = 2000;
  const progressPercent = Math.min((vitaminD / dailyTarget) * 100, 100);

  const redLightMinutes = time.hasRedLight ? calculateRedLightEquivalent(duration) : null;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-6 py-12 md:py-20">
        {/* Header */}
        <header className="mb-12">
          <h1 className="text-3xl md:text-4xl font-bold tracking-[-0.04em] leading-[1.05]">
            Full Spectrum
          </h1>
          <p className="text-sm text-muted-foreground font-mono mt-1.5 tracking-wide">
            Solar exposure calculator
          </p>
        </header>

        {/* Inputs */}
        <section className="space-y-8 mb-16">
          {/* Zip Code */}
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-3">
              Location
            </label>
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Zip code or city"
                value={zip}
                onChange={(e) => setZip(e.target.value)}
                onKeyDown={handleZipKeyDown}
                className="font-mono max-w-[200px] rounded-sm"
              />
              <button
                onClick={fetchWeather}
                disabled={loading || zip.length < 2}
                className="px-4 py-2 text-xs font-mono uppercase tracking-wider border border-border bg-background hover:bg-accent transition-colors disabled:opacity-40"
              >
                {loading ? '...' : 'Fetch'}
              </button>
            </div>
            {location && (
              <p className="text-xs font-mono text-muted-foreground mt-2">
                {location} · UV {currentUvi} · {temperature}°C
              </p>
            )}
          </div>

          <SkinTypeSelector selected={skinIndex} onSelect={setSkinIndex} />
          <BodyExposureSelector selected={bodyIndex} onSelect={setBodyIndex} />
          <TimePeriodSelector selected={timeIndex} onSelect={setTimeIndex} />

          {/* Duration */}
          <div>
            <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-3">
              Duration — {duration} min
            </label>
            <Slider
              value={[duration]}
              onValueChange={(v) => setDuration(v[0])}
              min={0}
              max={120}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-[10px] font-mono text-muted-foreground mt-1">
              <span>0</span>
              <span>60</span>
              <span>120 min</span>
            </div>
          </div>
        </section>

        {/* Divider */}
        <div className="border-t border-border mb-12" />

        {/* Vitamin D Output */}
        <section className="mb-12">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-4">
            Vitamin D Solar Budget
          </h2>
          <div className="flex items-baseline gap-2 mb-4">
            <span className="text-6xl md:text-7xl font-bold tracking-[-0.05em] leading-none font-mono">
              {vitaminD.toLocaleString()}
            </span>
            <span className="text-lg text-muted-foreground font-mono">IU</span>
          </div>
          <Progress value={progressPercent} className="h-1.5 rounded-none mb-2" />
          <p className="text-[10px] font-mono text-muted-foreground">
            {Math.round(progressPercent)}% of {dailyTarget.toLocaleString()} IU daily target
          </p>
          <p className="text-[10px] font-mono text-muted-foreground mt-2 opacity-60">
            20,000 × {hours.toFixed(2)}h × {(currentUvi / 10 * time.uviFactor).toFixed(2)} UVI
            × {skin.factor} skin × {body.factor} body
          </p>
        </section>

        {/* Red Light */}
        {time.hasRedLight && (
          <section className="mb-12">
            <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-4">
              Red Light Therapy Equivalent
            </h2>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold tracking-[-0.04em] leading-none font-mono">
                {redLightMinutes}
              </span>
              <span className="text-sm text-muted-foreground font-mono">
                min panel time
              </span>
            </div>
            <p className="text-[10px] font-mono text-muted-foreground mt-2 opacity-60">
              Sun red/NIR ≈ 10 mW/cm² vs panel ≈ 40 mW/cm²
            </p>
          </section>
        )}

        {/* Divider */}
        <div className="border-t border-border mb-12" />

        {/* Solar Spectrum */}
        <section className="mb-16">
          <h2 className="text-xs uppercase tracking-widest text-muted-foreground mb-4">
            Solar Spectrum Benefits
          </h2>
          <SpectrumStrip />
          <div className="mt-6">
            <SpectrumTable selectedTime={time.id} />
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border pt-6 text-[10px] font-mono text-muted-foreground opacity-50">
          Estimates only. Consult a healthcare provider. Data via Open-Meteo.
        </footer>
      </div>
    </div>
  );
};

export default Index;
