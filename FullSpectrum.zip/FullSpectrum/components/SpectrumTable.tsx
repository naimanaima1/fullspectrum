import { SPECTRUM_DATA, isSpectrumActive } from '@/lib/solar-calculations';
import { cn } from '@/lib/utils';

interface Props {
  selectedTime: string;
}

export function SpectrumTable({ selectedTime }: Props) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs font-mono">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-2 pr-3 font-medium text-muted-foreground uppercase tracking-wider">Type</th>
            <th className="text-left py-2 pr-3 font-medium text-muted-foreground uppercase tracking-wider">Benefit</th>
            <th className="text-left py-2 pr-3 font-medium text-muted-foreground uppercase tracking-wider hidden sm:table-cell">Target</th>
            <th className="text-left py-2 font-medium text-muted-foreground uppercase tracking-wider">Best Time</th>
            <th className="text-center py-2 pl-3 font-medium text-muted-foreground uppercase tracking-wider w-8">●</th>
          </tr>
        </thead>
        <tbody>
          {SPECTRUM_DATA.map((row) => {
            const active = isSpectrumActive(row.bestTime, selectedTime);
            return (
              <tr key={row.type} className={cn('border-b border-border/50', !active && 'opacity-30')}>
                <td className="py-2 pr-3 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full inline-block flex-shrink-0" style={{ backgroundColor: row.color }} />
                  {row.type}
                </td>
                <td className="py-2 pr-3">{row.benefit}</td>
                <td className="py-2 pr-3 hidden sm:table-cell text-muted-foreground">{row.target}</td>
                <td className="py-2 text-muted-foreground">{row.wavelength}</td>
                <td className="py-2 pl-3 text-center">
                  {active ? '●' : '○'}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
