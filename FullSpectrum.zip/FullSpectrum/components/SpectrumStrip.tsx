export function SpectrumStrip() {
  return (
    <div className="w-full h-3 rounded-sm overflow-hidden flex">
      <div className="flex-1" style={{ background: '#8B5CF6' }} title="UVB" />
      <div className="flex-1" style={{ background: '#A78BFA' }} title="UVA" />
      <div className="flex-1" style={{ background: '#3B82F6' }} title="Blue" />
      <div className="flex-1" style={{ background: '#22C55E' }} title="Green" />
      <div className="flex-1" style={{ background: '#F97316' }} title="Orange" />
      <div className="flex-1" style={{ background: '#EF4444' }} title="Red" />
      <div className="flex-1" style={{ background: '#DC2626' }} title="NIR" />
      <div className="flex-1" style={{ background: '#991B1B' }} title="FIR" />
    </div>
  );
}
