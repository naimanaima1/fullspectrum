import { TIME_PERIODS } from '@/lib/solar-calculations';
import { cn } from '@/lib/utils';

interface Props {
  selected: number;
  onSelect: (index: number) => void;
}

export function TimePeriodSelector({ selected, onSelect }: Props) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-3">
        Time of Day
      </label>
      <div className="flex gap-1">
        {TIME_PERIODS.map((t, i) => (
          <button
            key={t.id}
            onClick={() => onSelect(i)}
            className={cn(
              'flex-1 py-2.5 px-2 text-xs font-mono border transition-all',
              selected === i
                ? 'bg-foreground text-background border-foreground'
                : 'bg-background text-foreground border-border hover:bg-accent'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}
