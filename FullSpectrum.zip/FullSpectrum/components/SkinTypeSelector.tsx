import { SKIN_TYPES } from '@/lib/solar-calculations';
import { cn } from '@/lib/utils';

interface Props {
  selected: number;
  onSelect: (index: number) => void;
}

export function SkinTypeSelector({ selected, onSelect }: Props) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-3">
        Skin Type
      </label>
      <div className="flex gap-2">
        {SKIN_TYPES.map((skin, i) => (
          <button
            key={skin.type}
            onClick={() => onSelect(i)}
            className={cn(
              'w-10 h-10 rounded-sm transition-all border-2',
              selected === i
                ? 'border-foreground scale-110 shadow-md'
                : 'border-transparent hover:scale-105'
            )}
            style={{ backgroundColor: skin.color }}
            title={`Type ${skin.type}: ${skin.label} (×${skin.factor})`}
          />
        ))}
      </div>
      <p className="text-xs text-muted-foreground mt-1.5 font-mono">
        Type {SKIN_TYPES[selected].type} · {SKIN_TYPES[selected].label} · ×{SKIN_TYPES[selected].factor}
      </p>
    </div>
  );
}
