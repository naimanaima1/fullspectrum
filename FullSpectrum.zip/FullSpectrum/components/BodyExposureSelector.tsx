import { BODY_EXPOSURE } from '@/lib/solar-calculations';
import { cn } from '@/lib/utils';

interface Props {
  selected: number;
  onSelect: (index: number) => void;
}

export function BodyExposureSelector({ selected, onSelect }: Props) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-widest text-muted-foreground mb-3">
        Body Exposure
      </label>
      <div className="flex gap-1">
        {BODY_EXPOSURE.map((b, i) => (
          <button
            key={b.id}
            onClick={() => onSelect(i)}
            className={cn(
              'flex-1 py-2.5 px-3 text-xs font-mono border transition-all',
              selected === i
                ? 'bg-foreground text-background border-foreground'
                : 'bg-background text-foreground border-border hover:bg-accent'
            )}
          >
            <span className="block font-medium">{b.label}</span>
            <span className="block text-[10px] opacity-60 mt-0.5">{b.percent}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
