// Fitzpatrick skin type factors
export const SKIN_TYPES = [
  { type: 'I', label: 'Very Fair', factor: 1.0, color: '#FDDCB5' },
  { type: 'II', label: 'Fair', factor: 0.75, color: '#E8B88A' },
  { type: 'III', label: 'Medium', factor: 0.5, color: '#C9956B' },
  { type: 'IV', label: 'Olive', factor: 0.35, color: '#A67651' },
  { type: 'V', label: 'Brown', factor: 0.25, color: '#7B5139' },
  { type: 'VI', label: 'Very Dark', factor: 0.2, color: '#4A3228' },
] as const;

export const BODY_EXPOSURE = [
  { id: 'face', label: 'Face / Hands', factor: 0.1, percent: '10%' },
  { id: 'tshirt', label: 'Shorts & Tee', factor: 0.4, percent: '40%' },
  { id: 'swim', label: 'Swimsuit', factor: 0.8, percent: '80%' },
] as const;

export const TIME_PERIODS = [
  { id: 'sunrise', label: 'Sunrise', uviFactor: 0.1, hasRedLight: true },
  { id: 'midday', label: '10am–2pm', uviFactor: 1.0, hasRedLight: false },
  { id: 'afternoon', label: 'Afternoon', uviFactor: 0.6, hasRedLight: false },
  { id: 'sunset', label: 'Sunset', uviFactor: 0.1, hasRedLight: true },
] as const;

export function calculateVitaminD(
  hours: number,
  uvi: number,
  skinFactor: number,
  bodyFactor: number,
  timeUviFactor: number
): number {
  const uviFact = (uvi / 10) * timeUviFactor;
  return Math.round(20000 * hours * uviFact * skinFactor * bodyFactor);
}

export function calculateRedLightEquivalent(minutes: number): number {
  // Sun red: ~10 mW/cm², Panel: ~40 mW/cm² (midpoint of 30-50)
  // So sun minutes * (10/40) = equivalent panel minutes
  return Math.round(minutes * (10 / 40));
}

export const SPECTRUM_DATA = [
  { type: 'UVB', wavelength: '290–320 nm', benefit: 'Vitamin D3', target: 'Skin (Epidermis)', bestTime: 'midday', color: '#8B5CF6' },
  { type: 'UVA', wavelength: '320–400 nm', benefit: 'Lower Blood Pressure', target: 'Blood Vessels', bestTime: 'all', color: '#A78BFA' },
  { type: 'Blue', wavelength: '400–500 nm', benefit: 'Alertness / Sleep Reset', target: 'Eyes (Retina)', bestTime: 'sunrise', color: '#3B82F6' },
  { type: 'Green', wavelength: '495–570 nm', benefit: 'Pain Relief / Calm', target: 'Eyes / Skin', bestTime: 'morning_afternoon', color: '#22C55E' },
  { type: 'Orange', wavelength: '590–620 nm', benefit: 'Collagen / Wind-Down', target: 'Skin / Brain', bestTime: 'sunrise_sunset', color: '#F97316' },
  { type: 'Red', wavelength: '600–700 nm', benefit: 'Cellular Energy (ATP)', target: 'Skin / Tissue', bestTime: 'sunrise_sunset', color: '#EF4444' },
  { type: 'NIR', wavelength: '700–1400 nm', benefit: 'Deep Repair / Brain', target: 'Muscles / Brain', bestTime: 'all', color: '#DC2626' },
  { type: 'FIR', wavelength: '3000 nm – 1 mm', benefit: 'Detox / Blood Flow', target: 'Entire Body', bestTime: 'midday', color: '#991B1B' },
] as const;

export function isSpectrumActive(bestTime: string, selectedTime: string): boolean {
  if (bestTime === 'all') return true;
  if (bestTime === 'sunrise_sunset') return selectedTime === 'sunrise' || selectedTime === 'sunset';
  if (bestTime === 'midday') return selectedTime === 'midday';
  if (bestTime === 'sunrise') return selectedTime === 'sunrise';
  if (bestTime === 'morning_afternoon') return selectedTime === 'midday' || selectedTime === 'afternoon';
  return false;
}
