interface GeoResult {
  latitude: number;
  longitude: number;
  name: string;
  admin1?: string;
}

interface WeatherResult {
  uvi: number;
  temperature: number;
  location: string;
}

export async function geocodeZip(zip: string): Promise<GeoResult | null> {
  try {
    const res = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${zip}&count=1&language=en&format=json&country=US`
    );
    const data = await res.json();
    if (!data.results?.length) return null;
    const r = data.results[0];
    return { latitude: r.latitude, longitude: r.longitude, name: r.name, admin1: r.admin1 };
  } catch {
    return null;
  }
}

export async function getWeather(lat: number, lon: number): Promise<WeatherResult | null> {
  try {
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=uv_index,temperature_2m&timezone=auto`
    );
    const data = await res.json();
    return {
      uvi: data.current.uv_index,
      temperature: data.current.temperature_2m,
      location: '',
    };
  } catch {
    return null;
  }
}
